import javax.swing.*;
import java.awt.image.*;
import java.awt.event.*;
import java.io.*;
import javax.imageio.*;
import java.awt.event.KeyEvent;
import java.awt.*;
import javax.swing.JFrame;
import javax.swing.*;


public class Character{
	private int x, y;
	private char dir;
	private int xspeed, yspeed;
	private BufferedImage up[];
	private BufferedImage down[];
	private BufferedImage left[];
	private BufferedImage right[];
	private int currFrame, maxFrame;
	private char direction;
	private int tick, attackTimer, damage, linkdamage;
	private boolean hasSword, isAttacking, isMoving;
	private final int maxTick=1;
	private final int cha_w=22;
	private final int cha_h=35;
	private final int SPEED=5;
	private BufferedImage stab[];
	
	public Character(int _x, int _y){
		x=_x;
		y=_y;
		direction='d';
		attackTimer = 0;
		tick=0;
		currFrame=0;
		maxFrame=8;
		damage=10;
		up=new BufferedImage[9];
		down=new BufferedImage[9];
		left=new BufferedImage[9];
		right=new BufferedImage[9];
		setHasSword(false);
		stab=new BufferedImage[4];
		
		try{
			for(int i=0;i<9;i++){
				up[i]=ImageIO.read(new File("up_0"+(i+1)+".png"));
				down[i]=ImageIO.read(new File("down_0"+(i+1)+".png"));
				left[i]=ImageIO.read(new File("move_0"+(i+1)+".png"));
				right[i]=ImageIO.read(new File("left_0"+(i+1)+".png"));
			}
			stab[0]=ImageIO.read(new File("StabDown.png"));
			stab[1]=ImageIO.read(new File("StabUp.png"));
			stab[2]=ImageIO.read(new File("StabRight.png"));
			stab[3]=ImageIO.read(new File("StabLeft.png"));
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	public int getX(){return x;}
	public void setX(int i){x=i;}
	public int getY(){return y;}
	public void setY(int i){y=i;}
	public int getDamage() {return damage; }
	public void setDamage(int i) { damage = i; }
	public void setHasSword(boolean hasSword) {this.hasSword = hasSword;}
	public boolean hasSword() {return hasSword;}
	public boolean isAttacking(){return isAttacking;}
	public char getDirection(){return direction;}
	
	public void attack(){
		if (hasSword) {isAttacking = true;}
	}

	public void moveLeft(){
		x-=5;
	}
	
	public void moveRight(){
		x+=5;
	}
	
	public void moveUp(){
		y-=5;
	}
	
	public void moveDown(){
		y+=5;
	}

	public void stop() {
		isMoving = false;
	}
	
	public void move(char dir){
		direction = dir;
		isMoving = true;
	}
	
	private void self_move() {
		isAttacking = false;
		if(direction=='u'){
			y-=SPEED;
		}else if(direction=='d'){
			y+=SPEED;
		}else if(direction=='r'){
			x+=SPEED;
		}else if(direction=='l'){
			x-=SPEED;
		}
	}

	public void update(){
		if (isMoving) {self_move();}
	
		attackTimer++;
	    if (attackTimer == 20) {
	    	attackTimer = 0; isAttacking = false; 
	    }
		tick++;
		if(tick>maxTick){
			tick=0;
			currFrame++;
			if(currFrame>maxFrame){
				currFrame=0;
			}
		}
	}
	
	public void draw(Graphics g){
		if (isAttacking) {
			switch (direction) {
				case 'd': g.drawImage(stab[0],x,y,null);
					break;
				case 'l': g.drawImage(stab[3],x-40,y,null);
					break;
				case 'u': g.drawImage(stab[1],x,y-38,null);
					break;
				case 'r': g.drawImage(stab[2],x,y,null);
					break;
			}
		}else if(!isMoving){ 
			switch (direction) {
				case 'd': g.drawImage(down[0],x,y,null);
					break;
				case 'l': g.drawImage(left[0],x,y,null);
					break;
				case 'u': g.drawImage(up[0],x,y,null);
					break;
				case 'r': g.drawImage(right[0],x,y,null);
					break; 
			}
		}else switch (direction) {
			case 'd': g.drawImage(down[currFrame],x,y,null);
				break;
			case 'l': g.drawImage(left[currFrame],x,y,null);
				break;
			case 'u': g.drawImage(up[currFrame],x,y,null);
				break;
			case 'r': g.drawImage(right[currFrame],x,y,null);
				break; 
		}
	}

	private int top_x,top_y,width,height;

	public int getTopX(){return x;}
	public int getTopY(){return y;}
	public int getWidth(){return cha_w;}
	public int getHeight(){return cha_h;}

	
	
}