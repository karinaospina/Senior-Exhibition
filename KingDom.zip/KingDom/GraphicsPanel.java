import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class GraphicsPanel extends JPanel{
	private Screen s;
	private Character hero;
	private Character h, h2;

	public GraphicsPanel(){
 		s=new Screen();
 		s.setLevel(1);
 		hero=new Character(50,520);
	}
	
	public void moveDir(char c){
		int tx=hero.getX();
		int ty=hero.getY();
		if (c == 's') {
			hero.attack();
			return;
		}
		if(c=='u'){
			ty-=5;
			if(!s.level_collision(tx,ty,hero.getWidth(),hero.getHeight())){
				hero.move(c);
			}
		}
		if(c=='d'){
			ty+=5;
		    if(!s.level_collision(tx,ty,hero.getWidth(),hero.getHeight())){
				hero.move(c);
		    }
		}
		if(c=='l'){
			tx-=5;
		    if(!s.level_collision(tx,ty,hero.getWidth(),hero.getHeight())){
		      	hero.move(c);
		    }
		}
		if(c=='r'){
			tx+=5;
		    if(!s.level_collision(tx,ty,hero.getWidth(),hero.getHeight())){
		      	hero.move(c);
		    }
		}
		if(c=='x') {
		hero.stop();
		}
				System.out.println("hero"+hero.getX()+","+hero.getY());
	}
	
	public void reset(){
		 s.setLevel(1);
		 hero.setX(50);
		 hero.setY(520);
	 }
	
	public void update(){
		int tx=hero.getX();
		int ty=hero.getY();
		
		if(hero.getDirection()=='u'){
			ty-=5;
			
		    if(s.level_collision(tx,ty,hero.getWidth(),hero.getHeight())){
		    	hero.stop();
		    }
		}
		if(hero.getDirection()=='d'){
			ty+=5;
		    if(s.level_collision(tx,ty,hero.getWidth(),hero.getHeight())){
		    	hero.stop();
		    }
		}
		if(hero.getDirection()=='l'){
			tx-=5;
			if(s.level_collision(tx,ty,hero.getWidth(),hero.getHeight())){
				hero.stop();
			}
		}
		if(hero.getDirection()=='r'){
			tx+=5;
		    if(s.level_collision(tx,ty,hero.getWidth(),hero.getHeight())){
		    	hero.stop();
		    }
		}
		if (! hero.hasSword( ) ) {
			if (s.getLevel() == 3) {
				if (s.checkSword(tx,ty,hero.getWidth(),hero.getHeight()) ) {
					hero.setHasSword(true);
				}
			}
		}
		
		hero.update();
		s.update();
		int x = 0;
		int dmg=s.checkEnemy(hero.getX(),hero.getY(),hero.getWidth(),hero.getHeight(),x);
    	hero.setDamage(dmg);
		int swordDamage=hero.getDamage();
		
		if (hero.isAttacking() ) {
    		switch (hero.getDirection() ) {
    	case 'l':s.checkEnemy( hero.getX(),hero.getY(),hero.getWidth(),hero.getHeight(), swordDamage  );
    			break;
    	case 'r':s.checkEnemy( hero.getX(),hero.getY(),hero.getWidth(),hero.getHeight(), swordDamage  );
    			break;
    	case 'u':s.checkEnemy( hero.getX(),hero.getY(),hero.getWidth(),hero.getHeight(), swordDamage  );
    			break;
    	case 'd':s.checkEnemy( hero.getX(),hero.getY(),hero.getWidth(),hero.getHeight(), swordDamage  );
    			break;
    			default:System.out.println("Sword error, no direction");
    		}
    	}
    	
    	if(s.getLevel()==1){
    		if((hero.getX()>1015 && hero.getX()<1035) && hero.getY()==480){
    			s.setLevel(2);
    			hero.setX(530);
    			hero.setY(890);
    		}else if((hero.getX()>630 && hero.getX()<680) && hero.getY()==160){
    			s.setLevel(3);
    			hero.setX(640);
				hero.setY(890);
    		}else if((hero.getX()>790 && hero.getX()<840) && hero.getY()==900){
    			s.setLevel(4);
    			hero.setX(785);
				hero.setY(5);
    		}
    	}
    	
    	if(s.getLevel()==2){
    		if(hero.getY()>900){
		   	 	s.setLevel(1);
		   	 	hero.setX(1010);
		   	 	hero.setY(525);
    		}
    	}
    	
    	if(s.getLevel()==3){
    		if(hero.getY()>900){
    			s.setLevel(1);
    			hero.setX(650);
				hero.setY(180);
    		}
    	}
    	
    	if(s.getLevel()==4){
    		if(hero.getY()<0){
    			hero.setX(815);
				hero.setY(875);
				s.setLevel(1);
    		}
    	}    	
	}
	
	public void paint(Graphics g){
		s.draw(g);
		hero.draw(g);
	}

}