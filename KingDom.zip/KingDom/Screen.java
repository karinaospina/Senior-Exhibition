import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.io.*;
import javax.imageio.*;

public class Screen{
	private BufferedImage img[];
	private final int s_w=84;
	private final int s_h=80;
	private int level;
	private Sword sword;
	private Enemy heartless[];
	private int map[][]={
						{0,0,3,4,4,4,4,63,64,4,5,6,7,8},
						{1,0,3,4,4,4,4,65,66,4,9,10,11,12},
						{0,0,3,5,6,7,8,45,43,4,13,14,15,16},
						{0,0,3,9,10,11,12,45,43,4,17,18,19,20},
						{0,0,3,13,14,15,16,45,43,4,4,4,54,55},
						{0,0,3,17,18,19,20,45,43,4,4,4,56,57},
						{31,32,3,21,22,23,24,25,35,39,39,39,39,4},
						{33,34,3,26,27,28,29,30,36,37,42,28,29,4},
						{0,2,3,5,6,7,8,4,4,48,49,50,51,4},
						{0,0,3,9,10,11,12,4,4,48,49,52,53,4},
						{0,0,3,13,14,15,16,4,4,48,49,4,4,4},
						{0,0,3,17,18,19,20,4,4,48,49,4,4,4},
	};
				 
			
	private int map2[][]={
				 		{59,59,59,59,59,59,59,59,59,59,59,59,59,59},
						{59,59,59,59,59,59,59,59,59,59,59,59,59,59},
						{59,59,58,58,58,58,58,58,58,58,58,58,59,59},
						{59,59,58,58,58,58,58,58,58,58,58,58,59,59},
						{59,59,58,58,58,58,58,58,58,58,58,58,59,59},
						{59,59,58,58,58,58,58,58,58,58,58,58,59,59},
						{59,59,58,58,58,58,58,58,58,58,58,58,59,59},
						{59,59,58,58,58,58,58,58,58,58,58,58,59,59},
						{59,59,58,58,58,58,58,58,58,58,58,58,59,59},
						{59,59,58,58,58,58,58,58,58,58,58,58,59,59},
						{59,59,59,59,59,58,58,58,59,59,59,59,59,59},
						{59,59,59,59,59,59,58,59,59,59,59,59,59,59},					
	};
	private int map3[][]={
						{59,59,59,59,59,59,59,59,59,59,59,59,59,59},
						{59,67,68,67,68,67,68,67,68,67,68,67,67,59},
						{59,67,71,71,71,71,71,71,71,71,71,71,67,59},
						{59,67,71,71,71,71,71,71,71,71,71,71,67,59},
						{59,67,71,71,71,71,71,71,71,71,71,71,67,59},
						{59,67,71,71,71,71,71,71,71,71,71,71,67,59},
						{59,67,71,71,71,71,71,71,71,71,71,71,67,59},
						{59,67,71,71,71,71,71,71,71,71,71,71,67,59},
						{59,67,71,71,71,71,71,71,71,71,71,71,67,59},
						{59,67,71,71,71,71,71,71,71,71,71,71,67,59},
						{59,67,68,67,68,69,71,71,71,69,68,67,67,59},
						{59,59,59,59,59,59,71,71,71,59,59,59,59,59},
	};
	private int map4[][]={
				 		{59,59,59,59,59,59,59,59,59,74,59,59,59,59},
						{59,59,59,59,59,59,59,59,59,74,59,59,59,59},
						{59,59,73,73,73,73,73,73,73,73,73,73,59,59},
						{59,59,73,73,73,73,73,73,73,73,73,73,59,59},
						{59,59,73,73,73,73,73,73,73,73,73,73,59,59},
						{59,59,73,73,73,73,73,73,73,73,73,73,59,59},
						{59,59,73,73,73,73,73,73,73,73,73,73,59,59},
						{59,59,73,73,73,73,73,73,73,73,73,73,59,59},
						{59,59,73,73,73,73,73,73,73,73,73,73,59,59},
						{59,59,73,73,73,73,73,73,73,73,73,73,59,59},
						{59,59,59,59,59,59,59,59,59,59,59,59,59,59},
						{59,59,59,59,59,59,59,59,59,59,59,59,59,59},
	};
	
	public Screen(){
		img=new BufferedImage[75];
		try{
			img[0] = ImageIO.read(new File("water.jpg"));
     		img[1] = ImageIO.read(new File("boat.jpg"));
     		img[2] = ImageIO.read(new File("boat2.jpg"));
     		img[3] = ImageIO.read(new File("sand.jpg"));
     		img[4] = ImageIO.read(new File("grass.jpg"));
     		for(int i=0;i<16;i++)
  	 	    img[i+5] = ImageIO.read(new File("tree"+(i+1)+".jpg"));
    
     		img[21] = ImageIO.read(new File("road1.gif"));
		    img[22] = ImageIO.read(new File("road2.gif"));
     		img[23] = ImageIO.read(new File("road3.gif"));
     		img[24] = ImageIO.read(new File("road4.gif"));
     		img[25] = ImageIO.read(new File("road5.gif"));
     		img[26] = ImageIO.read(new File("road6.gif"));
     		img[27] = ImageIO.read(new File("road7.gif"));
     		img[28] = ImageIO.read(new File("road8.gif"));
     		img[29] = ImageIO.read(new File("road9.gif"));
     		img[30] = ImageIO.read(new File("road10.gif"));
  	 		img[35] = ImageIO.read(new File("road15.gif"));
  	 		img[36] = ImageIO.read(new File("road17.gif"));
  	 		img[37] = ImageIO.read(new File("road18.gif"));
  	 		img[38] = ImageIO.read(new File("road20.gif"));
  	 		img[39] = ImageIO.read(new File("road16.gif"));
  	 		img[40] = ImageIO.read(new File("road19.gif"));
  	 		img[41] = ImageIO.read(new File("road34.jpg"));
  	 		img[42] = ImageIO.read(new File("road20.gif"));
  	 		img[43] = ImageIO.read(new File("road14.gif"));
  	 		img[44] = ImageIO.read(new File("road15.gif"));
  	 		img[45] = ImageIO.read(new File("road13.gif"));
  	 		img[46] = ImageIO.read(new File("road11.gif"));
  	 		img[47] = ImageIO.read(new File("road12.gif"));
  	 		img[48] = ImageIO.read(new File("road23.gif"));
  	 		img[49] = ImageIO.read(new File("road24.gif"));
  	 
  	 		img[50] = ImageIO.read(new File("lake1.gif"));
  	 		img[51] = ImageIO.read(new File("lake2.gif"));
  	 		img[52] = ImageIO.read(new File("lake3.gif"));
  	 		img[53] = ImageIO.read(new File("lake4.gif"));
  	 		img[54] = ImageIO.read(new File("house1.gif"));
	 		img[55] = ImageIO.read(new File("house2.gif"));
	 		img[56] = ImageIO.read(new File("house3.gif"));
	 		img[57] = ImageIO.read(new File("house4.gif"));  
	 		img[58] = ImageIO.read(new File("housetile.gif"));	
	 		img[59] = ImageIO.read(new File("blacktile.jpg")); 
	 		img[60] = ImageIO.read(new File("carpet.jpg"));
	 		img[62] = ImageIO.read(new File("grass1.jpg"));
	 		img[63] = ImageIO.read(new File("castlething01.gif"));
	 		img[64] = ImageIO.read(new File("castlething02.gif"));
	 		img[65] = ImageIO.read(new File("castlething03.gif"));
	 		img[66] = ImageIO.read(new File("castlething04.gif"));
	 		img[67] = ImageIO.read(new File("castletiles1.gif"));
	 		img[68] = ImageIO.read(new File("castletiles2.gif"));
	 		img[69] = ImageIO.read(new File("statue.png"));
	 		img[70] = ImageIO.read(new File("castletiles4.gif"));
	 		img[71] = ImageIO.read(new File("insidetile.gif"));
	 		img[72] = ImageIO.read(new File("whitetile.gif"));
	 		img[73] = ImageIO.read(new File("levelfour.jpg"));
	 		img[74] = ImageIO.read(new File("levelfourroad.jpg"));
	 
     		for(int i=0;i<4;i++)
     		img[i+31] = ImageIO.read(new File("bridge"+(i+1)+".jpg"));
     		img[32] = ImageIO.read(new File("bridge2.jpg"));
     		img[33] = ImageIO.read(new File("bridge3.jpg"));
     		img[34] = ImageIO.read(new File("bridge4.jpg"));
		}catch(IOException e){
			e.printStackTrace();
		}
		
		level=1;
	}
	
	public int getLevel(){return level;}
	public void setLevel(int i){
		level = i;
		switch(i){
			case 1:
			heartless = new Enemy [4];
			heartless[0]=new Enemy(810,400,'r');
			heartless[1]=new Enemy(610,685,'r');
			heartless[2]=new Enemy(990,845,'r');
			heartless[3]=new Enemy(195,725,'r');
				break;
			case 2:
			heartless = new Enemy [4];
			heartless[0]=new Enemy(940,720,'r');
			heartless[1]=new Enemy(200,640,'r');
			heartless[2]=new Enemy(190,160,'r');
			heartless[3]=new Enemy(935,175,'r');
				break;
			case 3:	
			sword= new Sword(600,395);
				break;
			case 4:
			heartless = new Enemy [5];
			heartless[0]=new Enemy(200,200,'r');
			heartless[1]=new Enemy(300,300,'r');
			heartless[2]=new Enemy(400,400,'r');
			heartless[3]=new Enemy(500,500,'r');
			heartless[4]=new Enemy(600,600,'r');

				break;
		}
	}
	
	boolean bounding_box_collision(int b1_x, int b1_y, int b1_w, int b1_h, int b2_x, int b2_y, int b2_w, int b2_h){
    	if ((b1_x > b2_x + b2_w - 1) ||
        	(b1_y > b2_y + b2_h - 1) ||
        	(b2_x > b1_x + b1_w - 1) ||
        	(b2_y > b1_y + b1_h - 1)){
        	return false;
    	}
    	return true;
	}
	
	boolean level_collision(int b1_x,int b1_y,int b1_w,int b1_h){
		int x=0,y=0;
		int holder[][] = map;
    	switch (level) {
        	case 1: holder = map;
        		break;
   			case 2:holder = map2;
				break;
			case 3:holder = map3;
				break;
 			case 4:holder = map4;
				break; 
		}

	 	for(int i=0;i<12;i++){
	   		x=0;
	    	for(int j=0;j<14;j++){
		   		if (holder[i][j]==0||holder[i][j]==2||holder[i][j]==5||holder[i][j]==6||holder[i][j]==7||holder[i][j]==8||holder[i][j]==9||
		   			holder[i][j]==10||holder[i][j]==11||holder[i][j]==12||holder[i][j]==13||holder[i][j]==14||holder[i][j]==15||
		   			holder[i][j]==16||holder[i][j]==17||holder[i][j]==18||holder[i][j]==19||holder[i][j]==20||holder[i][j]==2||
		   			holder[i][j]==50||holder[i][j]==51||holder[i][j]==52||holder[i][j]==53||holder[i][j]==54||holder[i][j]==55||
		   			holder[i][j]==56||holder[i][j]==57|| holder[i][j]==59||holder[i][j]==63||holder[i][j]==64||holder[i][j]==65||holder[i][j]==66||
		   			holder[i][j]==67||holder[i][j]==68||holder[i][j]==69){
			  		if(bounding_box_collision(b1_x,b1_y,b1_w,b1_h,x,y,img[map[i][j]].getWidth(),img[map[i][j]].getHeight())){
			  			return true;
			  		}	  
		   		}
		   		x=x+s_w;
	      	}
	      	y=y+s_h;
	 	}
	    return false;
	}
	public int checkEnemy(int p1x,int p1y, int p1w, int p1h,int attackDamage){
	   for(int i=0;i<heartless.length;i++){
		   if(heartless[i].getHp()>0)
		   	if(bounding_box_collision(p1x, p1y,p1w,p1h,heartless[i].getX(),heartless[i].getY(),heartless[i].getWidth(),heartless[i].getHeight())){
		   	  		 if(attackDamage>0)heartless[i].takeDamage(attackDamage);
		   	  		 return heartless[i].getDamage();
		   	}
	} return 0;
}	
	public boolean checkSword(int lx,int ly, int lw, int lh) {
		if(bounding_box_collision(lx, ly, lw, lh,sword.getX(),sword.getY(),sword.getWidth(),sword.getHeight())){
   	  		sword.pickUp();
   	  		return true;
		}
		return false;
	}
	
	public void draw(Graphics g){
		int x=0,y=0;
		for(int i=0;i<12;i++){
   			x=0;
   			for(int j=0;j<14;j++){
   				switch(level){
    		 		case 1: g.drawImage(img[map[i][j]],x,y,null);
     					break;
     				case 2: g.drawImage(img[map2[i][j]],x,y,null);
     					break;
    				case 3: g.drawImage(img[map3[i][j]],x,y,null);
     					break;
     				case 4: g.drawImage(img[map4[i][j]],x,y,null);
     					break;
     			}     
      			x=x+s_w;
    		}
    		y=y+s_h;
 		}
 	 for(int i=0;i<heartless.length;i++){
		if(heartless[i].getHp()>0)
		heartless[i].draw(g);
 }
 		
 		try {
			if ( level ==3 ) {
				if ( ! sword.isPickedUp() ) {
					sword.draw(g); 
				}
			}
		}catch(Exception e) {
			System.out.println(e); 
		}
		}
	public boolean moveAI(Enemy m){
		char e_dir=m.getDirection();
		int fx=m.getX(),fy=m.getY();
		if(e_dir=='u')fy-=m.getSpeed();
		else if(e_dir=='d')fy+=m.getSpeed();
		else if(e_dir=='l')fx-=m.getSpeed();
		else if(e_dir=='r')fx+=m.getSpeed();

	if(level_collision(fx,fy,m.getWidth(), m.getHeight())){
		m.collide();
		return false;
	}

	m.setMove(true);
	return true;


}

public void update(){
	for(int i=0;i<heartless.length;i++){
	heartless[i].update();
		if(heartless[i].getHp()>0){
			if(moveAI(heartless[i]));
			else{
			}
		}
	}
	}
}

