import java.awt.event.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.*;

public class Game implements KeyListener, ActionListener{
	private Timer time;
	private JFrame win;
	private GraphicsPanel gp;
	private Character hero;
	private int key;
	
	public Game(){
		win=new JFrame("Kingdom Hearts");
		gp=new GraphicsPanel();
		win.add(gp);
		win.setSize(1176, 980);
		win.setVisible(true);
		time=new Timer(25, this);
		time.start();
		win.addKeyListener(this);
		key=0;
	}
	
	public void keyPressed(KeyEvent e){
		key++;
		if(e.getKeyCode()==87){
		//W-Up
			gp.moveDir('u');
		}
		else if(e.getKeyCode()==83){
		//S-Down
			gp.moveDir('d');
		}
  		else if(e.getKeyCode()==68){
		//D-Right
			gp.moveDir('r');
		}
		else if(e.getKeyCode()==65){
		//A-Left
			gp.moveDir('l');
		}else if (e.getKeyCode() ==32) {
			gp.moveDir('s');
		}
	}
	
	@Override
	public void keyReleased(KeyEvent e){
		key--;
		if (e.getKeyCode() == 32) {
			return;
		}else gp.moveDir('x');
	}
	
	public void actionPerformed(ActionEvent e){
		gp.update();
  		gp.repaint();
	}

	public static void main(String args[]){
 		new Game();
	}


	@Override
	public void keyTyped(KeyEvent arg0) {
	// TODO Auto-generated method stub
	}
}