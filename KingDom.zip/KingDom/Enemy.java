import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.io.*;
import javax.imageio.*;
import java.util.*;

public class Enemy{
	private int x,y,hp;
	private BufferedImage img[];
	private char direction;
	private int currframe;
	private int maxframe;
	private int tick;
	private final int maxtick=11;
	private int damage;
	private int speed;
	private boolean Moving;
	private boolean superRandom;
	

public int getWidth(){return img[0].getWidth();}
public int getHeight(){return img[0].getHeight();}
public int getX(){return x;}
public int getY(){return y;}


public Enemy(int x, int y){
		superRandom = true;
		Moving = false;
		this.x=x;
		this.y=y;
		hp=3;
direction=this.getRandomDirection();
		currframe=0;
		maxframe=1;
		tick=0;
		damage=1;
		speed=1;
			img=new BufferedImage[2];
		try{
			img[0] = ImageIO.read(new File("enemyleft.png"));
			img[1] = ImageIO.read(new File("enemyright.png"));
		}catch (IOException e){
			e.printStackTrace();
		}
	}
	

public Enemy(int x, int y, char d){
	Moving = false;
	this.x=x;
	this.y=y;
	hp=3;
	direction=d;
	currframe=0;
	maxframe=1;
	tick=0;
	damage=1;
	speed=1;
		img=new BufferedImage[2];
	try{
			img[0] = ImageIO.read(new File("enemyleft.png"));
			img[1] = ImageIO.read(new File("enemyright.png"));
		}catch (IOException e){
			e.printStackTrace();
		}
	}
	

public char getRandomDirection(){
Random rand=new Random();
int random=rand.nextInt();
		 for(int l=0; l < 1500 ; l++ ){
                        random = rand.nextInt(99);
            }
            if (random >= 0 && random <= 25) {
                        direction='r';
                        return direction;//right
            }
            if (random >= 26 && random <= 50){
                        direction='l';
                        return direction;//left
            }           
            if (random >= 51 && random <= 75){
                        direction='u';
                        return direction;//up
            }
           if (random >= 76 && random <= 100){
                      direction='d';
                       return direction;//downs
           }
 return 0;
}


public void collide() {
	this.switchDirection();
	if (superRandom) {
            direction = getRandomDirection();
            }
	this.move();
}

public void switchDirection(){
	if(direction=='l')direction='r';
	else if(direction =='r')direction='l';
	else if(direction =='d')direction='u';
	else if(direction =='u')direction='d';
}
public char getDirection(){return direction;}
public int getHp(){return hp;}
public int getSpeed(){return speed;}
public void takeDamage(int v){hp=-v;}
public int getDamage(){return damage;}
public void draw(Graphics g){
	g.drawImage(img[currframe],x,y,null);
}
public void move(){
if (x<0 || x > 1450 || y < 0 || y >1000) {
            this.switchDirection();         
}
if(direction=='u'){y-=5;}
else if(direction=='d'){y+=5;}
else if(direction=='l'){x-=5;}
else if(direction=='r'){x+=5;}
}

public void setMove(boolean p) {
Moving = p; }


public void update(){
this.move();
	tick++;
		if(tick>maxtick){
	tick=0;
	currframe++;
	if(currframe>maxframe){
		currframe=0;
	}
   }
  }
 }
